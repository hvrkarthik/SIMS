-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 03, 2019 at 05:59 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sims`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `att_id` int(20) NOT NULL auto_increment,
  `stud_id` varchar(20) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY  (`att_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`att_id`, `stud_id`, `subject_id`, `date`, `time`, `status`) VALUES
(1, 'id', '', '2010-10-10', '2', 'dd');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(20) NOT NULL auto_increment,
  `name` varchar(25) NOT NULL,
  `desc` text NOT NULL,
  `fees` varchar(40) NOT NULL,
  PRIMARY KEY  (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `name`, `desc`, `fees`) VALUES
(1, 'CSE', 'Computer Science & Engineering', '15000'),
(2, 'MECH', 'Mechanical Engineering', '21000'),
(3, 'CE', 'Civil Engineerinng', '18000'),
(4, 'E&C', 'Electronics & communication Engineering', '15000'),
(5, 'E&E', 'Electrical & Electronics Engineering', '15000');

-- --------------------------------------------------------

--
-- Table structure for table `course_subject`
--

CREATE TABLE `course_subject` (
  `cs_id` int(20) NOT NULL auto_increment,
  `course_id` varchar(35) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  `semester` int(30) NOT NULL,
  PRIMARY KEY  (`cs_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `course_subject`
--

INSERT INTO `course_subject` (`cs_id`, `course_id`, `subject_id`, `semester`) VALUES
(22, '528cs', '15CS52T', 5),
(23, '19', '10', 7),
(24, '19', '6', 5),
(26, '19', '6', 5),
(27, '19', '6', 2),
(28, '1', '11', 6),
(29, '1', '14', 6),
(30, '1', '13', 6),
(31, '1', '12', 6),
(32, '1', '15', 6);

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `exam_id` int(15) NOT NULL auto_increment,
  `exam_name` varchar(100) NOT NULL,
  `min_marks` int(15) NOT NULL,
  `max_marks` int(15) NOT NULL,
  `exam_date` date NOT NULL,
  `course_id` int(15) NOT NULL,
  `semester` int(15) NOT NULL,
  `desc` varchar(500) NOT NULL,
  PRIMARY KEY  (`exam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exam_id`, `exam_name`, `min_marks`, `max_marks`, `exam_date`, `course_id`, `semester`, `desc`) VALUES
(1, '    LRMPS', 627, 700, '2018-11-27', 19, 5, '    BTPSP'),
(2, '    ghgj', 652, 700, '2018-11-06', 19, 6, '    ghgj'),
(3, 'qq', 142, 144, '2000-12-12', 19, 4, 'sddf'),
(5, 'ww', 23, 233, '0000-00-00', 27, 3, 'dfd'),
(6, ' ww', 23, 233, '0000-00-00', 19, 3, ' dfd'),
(7, 'MANISHA', 450, 600, '2018-12-27', 24, 5, 'ggu'),
(8, 'internal', 7, 20, '2019-01-21', 1, 6, 'internal assessment'),
(14, ' semester11', 440, 625, '2019-01-15', 5, 6, ' ee'),
(15, 'sss', 366, 400, '2019-07-07', 1, 5, 'ss'),
(16, 'aaa', 299, 300, '2019-10-10', 1, 3, 's');

-- --------------------------------------------------------

--
-- Table structure for table `exam_subject`
--

CREATE TABLE `exam_subject` (
  `es_id` int(15) NOT NULL auto_increment,
  `exam_id` varchar(15) NOT NULL,
  `subject_id` varchar(15) NOT NULL,
  `course_id` varchar(15) NOT NULL,
  `semester` int(15) NOT NULL,
  PRIMARY KEY  (`es_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `exam_subject`
--

INSERT INTO `exam_subject` (`es_id`, `exam_id`, `subject_id`, `course_id`, `semester`) VALUES
(4, '2', '10', '19', 4),
(5, '1', '6', '19', 6),
(6, '2', '10', '19', 6),
(10, '652', 'LRMPS', 'cse', 5),
(11, '652', 'LRMPS', 'dd', 5),
(12, '652', 'LRMPS', 'ee', 4),
(13, '652', '', 'CSE', 4),
(14, '', 'NSM', 'CSE', 5),
(15, '', 'NSM', 'CSE', 3),
(16, '', '', 'CSE', 6),
(17, '', 'NSM', 'CSE', 5),
(18, '', 'NSM', 'CSE', 5);

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `fees_id` int(20) NOT NULL auto_increment,
  `stud_id` int(25) NOT NULL,
  `date` date NOT NULL,
  `amount` int(30) NOT NULL,
  `mode_of_payment` text NOT NULL,
  `mode_no` text NOT NULL,
  PRIMARY KEY  (`fees_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`fees_id`, `stud_id`, `date`, `amount`, `mode_of_payment`, `mode_no`) VALUES
(16, 0, '2015-05-05', 500, 'cash', '123'),
(19, 15, '0000-00-00', 1244, 'cash', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(40) NOT NULL,
  `password` varchar(15) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `hint_q` varchar(50) NOT NULL,
  `hint_a` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `usertype`, `hint_q`, `hint_a`) VALUES
('pradnya', '2914', 'student', '', 'answer'),
('smita', '1234', 'student', '', 'answer'),
('CRUG', '235411', 'ADMIN', '', ''),
('manisha10@gmail.com', 'princess10', 'admin', '', 'paneer'),
('manisha10@gmail.com', 'princess10', 'admin', 'my fav food', 'paneer'),
('sk', '12345678', 'student', 'xyz', 'zyx');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(20) NOT NULL auto_increment,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `p_address` varchar(500) NOT NULL,
  `mobile_no` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `quali` varchar(50) NOT NULL,
  `course_id` varchar(20) NOT NULL,
  `joining_date` date NOT NULL,
  `photo_link` varchar(100) NOT NULL,
  PRIMARY KEY  (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `fname`, `lname`, `dob`, `gender`, `p_address`, `mobile_no`, `email`, `quali`, `course_id`, `joining_date`, `photo_link`) VALUES
(8, 'Nikhil', 'kallimani', '1984-07-27', 'Male', 'Belgum', '7353106072', 'nikhil.kallimani@gmail.com', 'M.tech', '1', '2008-02-02', 'xyz'),
(9, 'Girish', 'Chougale', '1990-08-12', 'male', 'Lakhanapur', '123456789', 'girishchougale@gmail.com', 'BE', '1', '2009-02-10', 'abc'),
(10, 'Tejashri', 'Shiraguppe', '1993-11-02', 'female', 'Shamanewadi', '7899211267', 'tejashrishiraguppe11@gmail.com', 'BE', '1', '2017-11-11', 'abc'),
(11, 'Sneha ', 'Chougule', '1996-05-11', 'female', 'Galataga', '7353233474', 'snehachougule108@gmail.com', 'BCA', '1', '2016-07-13', 'bcd'),
(12, 'Bhagyashree', 'Patil', '1995-07-01', 'Female', 'Galataga', '7795471795', '17bhagyapatil@gmail.com', 'BCA', '1', '2016-08-11', 'bcf');

-- --------------------------------------------------------

--
-- Table structure for table `staff_subject`
--

CREATE TABLE `staff_subject` (
  `staff_subject_id` int(30) NOT NULL auto_increment,
  `staff_id` int(30) NOT NULL,
  `subject_id` varchar(30) NOT NULL,
  PRIMARY KEY  (`staff_subject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `staff_subject`
--

INSERT INTO `staff_subject` (`staff_subject_id`, `staff_id`, `subject_id`) VALUES
(1, 9, '13 '),
(3, 8, '12 '),
(5, 10, '11 '),
(6, 9, '14 '),
(7, 10, '15 ');

-- --------------------------------------------------------

--
-- Table structure for table `student_marks`
--

CREATE TABLE `student_marks` (
  `sm_id` int(15) NOT NULL auto_increment,
  `es_id` int(15) NOT NULL,
  `stud_id` int(15) NOT NULL,
  `marks` int(15) NOT NULL,
  PRIMARY KEY  (`sm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `student_marks`
--

INSERT INTO `student_marks` (`sm_id`, `es_id`, `stud_id`, `marks`) VALUES
(1, 4, 17, 652),
(2, 5, 15, 1),
(3, 4, 14, 5),
(4, 4, 14, 0),
(5, 4, 14, 0),
(6, 0, 0, 0),
(7, 0, 0, 0),
(8, 12, 2, 25);

-- --------------------------------------------------------

--
-- Table structure for table `student_master`
--

CREATE TABLE `student_master` (
  `stud_id` int(20) NOT NULL auto_increment,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(15) NOT NULL,
  `p_address` varchar(30) NOT NULL,
  `phone_no` bigint(20) NOT NULL,
  `c_address` varchar(30) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `usn` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `caste` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `gaurdian_name` varchar(20) NOT NULL,
  `gaurdian_contact` bigint(25) NOT NULL,
  `semester` int(20) NOT NULL,
  `fees` int(30) NOT NULL,
  `joining_date` date NOT NULL,
  `photo_link` varchar(30) NOT NULL,
  `course_id` varchar(30) NOT NULL,
  `library` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY  (`stud_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `student_master`
--

INSERT INTO `student_master` (`stud_id`, `fname`, `lname`, `dob`, `gender`, `p_address`, `phone_no`, `c_address`, `mobile_no`, `usn`, `email`, `religion`, `caste`, `category`, `gaurdian_name`, `gaurdian_contact`, `semester`, `fees`, `joining_date`, `photo_link`, `course_id`, `library`, `status`) VALUES
(18, 'Surekha', 'Kanerkar', '2000-07-05', 'Female', 'Tavandi', 6361281448, 'Stavanidhi', 6361281448, '20', 'surekhakanerkar31@gmail.com', 'Hindu', '96 Maratha', 'III B', 'Sudhir Kanerkar', 9902250016, 6, 15000, '2016-07-01', 'abcd3', '1 ', 'xyz', 'aaa'),
(19, 'Manisha', 'Dinde', '1998-03-19', 'Female', 'Soundalga', 9380707419, 'Soundalga', 9380707419, '08', 'manishadinde10@gmail.com', 'Hindu', '96 Maratha', 'III B', 'Suryakant Dinde', 9890122929, 6, 15000, '2016-07-13', 'assd', '1 ', 'sd', 'adr'),
(20, 'Lata', 'Patil', '1995-05-15', 'Female', 'Chikhalwal', 9980226549, 'Chikhalwal', 9980226549, '02', 'latapatil0615@gmail.com', 'Hindu', '96 Maratha', 'III B', 'Dadasaheb Patil', 7338081158, 6, 22000, '2013-07-07', 'bka', '1 ', 'xyz', 'cn'),
(21, 'Ravina', 'Lohar', '1999-03-07', 'Female', 'Nipani', 7204040512, 'Nipani', 7204040512, '06', 'ravinalohar8@gmail.com', 'Hindu', '96 Maratha', '2A', 'Ramnath Lohar', 9448692761, 6, 20000, '2015-07-01', 'sh', '1 ', 'sdd', 'ss'),
(22, 'Pradnya', 'Nandani', '2001-01-14', 'Female', 'Galataga', 1234567893, 'Galataga', 1234567893, '10', 'pradnyanandni@gmail.com', 'Hindu', 'Jain', 'III B', 'Bhupal Nandani', 1234567893, 6, 7000, '2016-07-11', 'zx', '1 ', 'sss', 's');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `ss_id` int(20) NOT NULL auto_increment,
  `stud_id` varchar(20) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  PRIMARY KEY  (`ss_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `student_subject`
--

INSERT INTO `student_subject` (`ss_id`, `stud_id`, `subject_id`) VALUES
(29, '18', '11'),
(30, '19', '11'),
(31, '20', '11'),
(32, '21', '11'),
(33, '22', '11');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(20) NOT NULL auto_increment,
  `sub_name` varchar(30) NOT NULL,
  `desc` varchar(30) NOT NULL,
  `no_of_hours` varchar(30) NOT NULL,
  `credits` varchar(40) NOT NULL,
  PRIMARY KEY  (`subject_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `sub_name`, `desc`, `no_of_hours`, `credits`) VALUES
(11, 'NSM', 'Network Security Management', '40', '40'),
(12, 'ISM', 'Information storage Managment', '30', '30'),
(13, 'ST', 'Software Testing', '20', '20'),
(14, 'ST lab', 'Software Testing Lab', '15', '15'),
(15, 'NSM lab', 'Network Security Managment Lab', '20', '20');
